#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=actual_final_rudder_code.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/actual_final_rudder_code.X.production.hex
