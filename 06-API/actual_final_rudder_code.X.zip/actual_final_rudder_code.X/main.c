#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/uart1.h"
#include "stdio.h"
#include "string.h"

float time_ms;
float tenths;
float thirds;
float seconds;
float time_down;
float five_seconds;
float receive_start;
int i = 0;
int j = 0;
int steer = 0;
uint8_t byte;
uint8_t tempbyte;
uint8_t distance;
uint8_t prefix[2] = {'A','Z'};
uint8_t suffix[2] = {'Y','B'};
uint8_t receiveBuffer[60];
uint8_t sendBuffer[4];
bool check1 = false;
bool check2 = false;
bool last_state = true;

void TimerCallback(void);
void SendDistance(uint8_t data);
void RollCall(void);
void ReceiveMessage(void);
void ReactMessage(void);

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    UART1_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    TMR0_OverflowCallbackRegister(TimerCallback);
    TMR0_Start();

    while(1)
    {
        if (steer == 0){
            IO_RC0_SetLow();
            IO_RC1_SetLow();
        }
        if (steer == 1){
            IO_RC0_SetHigh();
            IO_RC1_SetLow();
        }
        if (steer == 2){
            IO_RC0_SetLow();
            IO_RC1_SetHigh();
        }
        if(tenths >= 100){ // Timer is working
            tenths -= 100;
        ReceiveMessage();
        }
    }    
}

void TimerCallback(void){
    time_ms++;
    tenths++;
    thirds++;
    seconds++;
    five_seconds++;
    if(thirds >= 333){
        thirds -= 333;
    }
}



void RollCall(void){
    uint8_t twelve = 12;
    printf("AZEX%hhuYB", twelve);
}

void ReceiveMessage(void){
    i = 0;
    j = 0;
    check1 = 0;
    check2 = 0;
    memset(receiveBuffer, 0, sizeof(receiveBuffer));
    receive_start = time_ms;
    while(1){
        if(time_ms - receive_start > 200){ //Timer is fine
            return;
        }
        if(UART1_IsRxReady()){ //UART is now ready
            byte = UART1_Read();
            j++;
            if((check1 == 0)&&(check2 == 0)&&(j>64)){
                printf("\r\nError: Prefix never received!!!\r\n");
                return;
            }
            else if(i>59){
                printf("\r\nError: Message too long!!!\r\n");
                return;
            }
            else if((byte == prefix[0])&&(check1 == 0)){
                check1 = 1;
            }
            else if((byte == prefix[1])&&(check1 == 1)&&(check2 == 0)){
                check2 = 1;
            }
            else if((check1 == 1)&&(check2 == 1)&&(i <= 59)&&(byte != suffix[0])){
                receiveBuffer[i] = byte;
                i++;
            }
            else if((check1 == 1)&&(check2 == 1)&&(byte == suffix[0])){
                tempbyte = byte;
                while(UART1_IsRxReady() == 0);
                byte = UART1_Read();
                if(byte == suffix[1]){
                    ReactMessage();
                    return;
                }
                else if(byte == suffix[0]){
                    receiveBuffer[i] = tempbyte;
                    i++;
                    tempbyte = byte;
                    while(UART1_IsRxReady() == 0);
                    byte = UART1_Read();
                    if(byte == suffix[1]){
                        ReactMessage();
                        return;
                    }
                    else{
                        printf("\r\nError: Three 'Y's in a row is evil!!!\r\n");
                        return;
                    }
                }
                else{
                    receiveBuffer[i] = tempbyte;
                    i++;
                    receiveBuffer[i] = byte;
                    i++;
                }
            }
            else{
            }
        }
    }
}

void ReactMessage(void){
    if((receiveBuffer[0] < 'A')||(receiveBuffer[0] > 'J')){
        printf("\r\nError: Sender ID not recognized!!!\r\n");
        return;
    }
    else if(((receiveBuffer[1] < 'A')||(receiveBuffer[1] > 'J'))&&(receiveBuffer[1] != 'X')){
        printf("\r\nError: Receiver ID not recognized!!!\r\n");
        return;
    }
    else if(receiveBuffer[1]=='X'){
        if(receiveBuffer[0]=='E'){  //Make sure you have your letter (E) listed for your address
            printf("\r\nThis was a broadcast message sent from self: noted and trashed.\n\r");
            return;
        }
        else{
            printf("\r\nBroadcast message noted/acted upon and passed along:\n\r");
            printf("AZ");
            for(int z=0; z<i; z++){
                printf("%c", receiveBuffer[z]);
            }
            printf("YB\r\n");
            return;
        }
    }
    else if(receiveBuffer[0]=='E'){
        printf("\r\nMessage is from self: message trashed.\r\n");
        return;
    }
    else if(receiveBuffer[1]=='E'){
        printf("\r\nThe following message is meant for me:\r\n");
        for(int x=0; x<i; x++){
            printf("%c", receiveBuffer[x]);
        }
        printf("\r\n");
        if (receiveBuffer[3]=='L' && receiveBuffer[2] == 'A'){
            steer = 1;
        }
        if (receiveBuffer[3]=='R' && receiveBuffer[2] == 'A'){
            steer = 2;
        }
        if (receiveBuffer[3]=='F' && receiveBuffer[2] == 'A'){
            steer = 0;
        }
        return;
    }
    else if(receiveBuffer[1]!= 'E'){
        putch('A');
        putch('Z');
        for(int w=0; w<i; w++){
            putch(receiveBuffer[w]);
        }
        putch('Y');
        putch('B');
        return;
    }
    else{
        printf("AZ");
        for(int y=0; y<i; y++){
            printf("%d", receiveBuffer[y]);
        }
        printf("YB\r\n");
        return;
        }
}